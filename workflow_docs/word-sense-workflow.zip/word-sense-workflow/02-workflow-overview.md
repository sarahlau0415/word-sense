# 工作流整体说明

## 三步工作流

```
输入:一个英文词 (例如 "brainrot")

         ↓

┌────────────────────────────────────┐
│ Step 1: 写作                       │
│ 用 v3-write prompt 调用 Claude API │
│ 输入:词                            │
│ 输出:六维骨架解读初稿              │
└────────────────────────────────────┘

         ↓

┌────────────────────────────────────┐
│ Step 2: 查证(Agent)                │
│ 用 v3-research prompt 调用 Claude  │
│ Claude 在此步骤需要调用工具:        │
│   - web_search (查事实)            │
│   - web_fetch (读网页内容)         │
│ 输入:Step 1 的初稿                 │
│ 输出:查证报告(✅/⚠️/❓/❌ 分类)      │
└────────────────────────────────────┘

         ↓

┌────────────────────────────────────┐
│ Step 3: 改写                       │
│ 用 v3-rewrite prompt 调用 Claude   │
│ 输入:Step 1 初稿 + Step 2 报告     │
│ 输出:改写后的终稿 + 改动说明        │
└────────────────────────────────────┘

         ↓

输出:三份 markdown 文件
```

## 三步之间的数据流

**Step 1 → Step 2:**
- Step 2 的输入是 **Step 1 的完整输出 + 词本身**
- Step 2 不需要原始 Step 1 prompt(避免污染)

**Step 2 → Step 3:**
- Step 3 的输入是 **Step 1 的初稿 + Step 2 的查证报告**(两者拼接给 Claude)
- Step 3 需要看到 Step 1 完整内容,知道改什么;需要看到 Step 2 完整报告,知道怎么改

## 关键约束

**Step 2 必须有工具调用能力。**

这是工作流的核心。没有工具调用,Step 2 只能让 AI 标注"我不确定",但不能真的去查证。

Claude API 支持工具调用(tool use),可以让 Claude 在响应过程中调用:
- `web_search`:搜索网页
- `web_fetch`:抓取特定 URL 内容(可选,看 Anthropic 提供的工具)

具体实现请参考 Anthropic API 的 tool use 文档:
https://docs.anthropic.com/en/docs/build-with-claude/tool-use

如果使用 Claude API 的内置 web 搜索能力,会简单很多。如果没有,可以接入第三方搜索 API(Tavily / Brave / Serper 等)。

**Step 3 不需要工具调用,纯文本输入输出。**

## 失败处理

每一步都可能失败:

- **Step 1 失败**:报错,整个工作流停止。让用户重试。
- **Step 2 失败**:有两种情况:
  - 完全失败(API 错误):停止,让用户重试
  - 部分失败(某些事实查不到):**仍然继续 Step 3**,但在 Step 2 报告里明确标注 "无法验证" 的项
- **Step 3 失败**:报错,但保留 Step 1 和 Step 2 的输出,用户可以手动改写

## 时间和成本预期

每个词的完整工作流大约:

- Step 1: 10-30 秒(纯文本生成)
- Step 2: 1-3 分钟(取决于查证调用次数,平均 3-5 次工具调用)
- Step 3: 10-30 秒

**总计每个词约 2-4 分钟,API 成本约 0.05-0.15 美元(取决于使用的 Claude 模型)。**

## 模型选择建议

推荐:`claude-opus-4-7` 或 `claude-sonnet-4-6`

- **Step 1**:Opus(质量优先)
- **Step 2**:Opus(查证需要判断力)
- **Step 3**:Sonnet 或 Opus 都可以

如果想省钱,全用 Sonnet 也可,质量略降但仍可用。
