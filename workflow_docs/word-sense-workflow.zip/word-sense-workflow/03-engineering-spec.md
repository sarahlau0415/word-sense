# 工程实现规格

## 推荐技术栈

**首选:Python**(因为 Anthropic 官方 SDK 在 Python 上最成熟,且 Codex 用 Python 写脚本时更顺手)

如果你倾向 Node.js 也可以,但需要确认 Anthropic SDK 的 tool use 在 Node 上工作正常。

## 依赖

```
anthropic>=0.40.0  # 至少这个版本,才支持最新的工具调用 API
python-dotenv
```

## 项目结构建议

```
word-sense-workflow/
├── prompts/
│   ├── v3-write.md
│   ├── v3-research.md
│   └── v3-rewrite.md
├── output/                  # 工作流跑出来的文件存这里
│   └── [word]/
│       ├── step-1-draft.md
│       ├── step-2-research.md
│       └── step-3-final.md
├── run.py                   # 主入口
├── .env                     # ANTHROPIC_API_KEY=...
└── requirements.txt
```

## 主流程伪代码

```python
import os
from pathlib import Path
import anthropic
from dotenv import load_dotenv

load_dotenv()
client = anthropic.Anthropic()  # 从 env 读取 API key

# 配置
MODEL = "claude-opus-4-7"  # 或 claude-sonnet-4-6
PROMPTS_DIR = Path("prompts")
OUTPUT_DIR = Path("output")

# 加载 prompts(从 markdown 文件读取 PROMPT 内容那一段)
def load_prompt(name: str) -> str:
    """读 prompts/[name].md 文件,提取 '## PROMPT 内容' 那一段。"""
    content = (PROMPTS_DIR / f"{name}.md").read_text(encoding="utf-8")
    # 找到 "## PROMPT 内容" 之后的内容
    marker = "## PROMPT 内容"
    if marker in content:
        # 取 marker 之后的内容,从第一个 "---" 之后开始
        after_marker = content.split(marker, 1)[1]
        # 跳过说明文字,找到实际 prompt(通常以 "你是..." 开头)
        parts = after_marker.split("---", 2)
        if len(parts) >= 3:
            return parts[2].strip()  # 返回 "---" 之间的核心 prompt
    return content  # 兜底:返回全文

V3_WRITE_PROMPT = load_prompt("v3-write")
V3_RESEARCH_PROMPT = load_prompt("v3-research")
V3_REWRITE_PROMPT = load_prompt("v3-rewrite")


def step_1_write(word: str, source: str = "", original_sentence: str = "") -> str:
    """Step 1: 用 v3-write 生成初稿。"""
    user_message = f"词:{word}"
    if source:
        user_message += f"\n出处:{source}"
    if original_sentence:
        user_message += f"\n原句:{original_sentence}"
    
    response = client.messages.create(
        model=MODEL,
        max_tokens=4000,
        system=V3_WRITE_PROMPT,
        messages=[{"role": "user", "content": user_message}]
    )
    return response.content[0].text


def step_2_research(word: str, draft: str) -> str:
    """Step 2: 用 v3-research 调用工具查证。"""
    user_message = f"""请查证以下这篇关于英文词 "{word}" 的解读初稿。

---

{draft}

---

按你的工作流执行,输出查证报告。
"""
    
    # 这里需要根据 Anthropic SDK 当前的 tool use API 调整
    # 参考 https://docs.anthropic.com/en/docs/build-with-claude/tool-use
    response = client.messages.create(
        model=MODEL,
        max_tokens=8000,
        system=V3_RESEARCH_PROMPT,
        tools=[
            {
                "type": "web_search_20250305",  # 以当前 API 文档为准
                "name": "web_search"
            }
        ],
        messages=[{"role": "user", "content": user_message}]
    )
    
    # 工具调用会产生多轮交互,需要处理 tool_use 和 tool_result
    # 最终从 response.content 里提取文本
    final_text = ""
    for block in response.content:
        if hasattr(block, "text"):
            final_text += block.text
    
    return final_text


def step_3_rewrite(word: str, draft: str, research_report: str) -> str:
    """Step 3: 用 v3-rewrite 根据查证报告改写。"""
    user_message = f"""请改写以下关于英文词 "{word}" 的解读初稿。

# Step 1 初稿

---

{draft}

---

# Step 2 查证报告

---

{research_report}

---

按你的工作流执行,输出改写后的终稿 + 改动说明。
"""
    
    response = client.messages.create(
        model=MODEL,
        max_tokens=6000,
        system=V3_REWRITE_PROMPT,
        messages=[{"role": "user", "content": user_message}]
    )
    return response.content[0].text


def run_workflow(word: str, source: str = "", original_sentence: str = ""):
    """跑完整工作流。"""
    output_dir = OUTPUT_DIR / word
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"=== Step 1: 写作 '{word}' ===")
    draft = step_1_write(word, source, original_sentence)
    (output_dir / "step-1-draft.md").write_text(draft, encoding="utf-8")
    print(f"  保存到 {output_dir}/step-1-draft.md")
    print(f"  长度:{len(draft)} 字")
    
    print(f"\n=== Step 2: 查证 ===")
    research = step_2_research(word, draft)
    (output_dir / "step-2-research.md").write_text(research, encoding="utf-8")
    print(f"  保存到 {output_dir}/step-2-research.md")
    print(f"  长度:{len(research)} 字")
    
    print(f"\n=== Step 3: 改写 ===")
    final = step_3_rewrite(word, draft, research)
    (output_dir / "step-3-final.md").write_text(final, encoding="utf-8")
    print(f"  保存到 {output_dir}/step-3-final.md")
    print(f"  长度:{len(final)} 字")
    
    print(f"\n✓ 工作流完成。三份文件都在 {output_dir}/")


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("用法:python run.py <英文词> [出处] [原句]")
        sys.exit(1)
    
    word = sys.argv[1]
    source = sys.argv[2] if len(sys.argv) > 2 else ""
    sentence = sys.argv[3] if len(sys.argv) > 3 else ""
    
    run_workflow(word, source, sentence)
```

## 关于 Tool Use 的具体实现

上面的 `step_2_research` 函数里 tools 参数的格式**以 Anthropic 当前 API 文档为准**。Anthropic API 的工具调用机制可能需要多轮交互:

1. Claude 决定调用工具(返回 `tool_use` block)
2. 你执行工具(实际跑 web search)
3. 把工具结果返回给 Claude(`tool_result` block)
4. Claude 继续生成,可能再次调用工具
5. 直到 Claude 输出最终文本

**如果使用 Anthropic 提供的内置 web search 工具**,大部分这套循环 Anthropic 会帮你处理。

**如果使用第三方搜索 API**(Tavily / Brave / Serper),需要自己实现这个循环。一个简化的循环结构:

```python
def step_2_research_with_loop(word: str, draft: str) -> str:
    messages = [
        {"role": "user", "content": f"查证 '{word}' 这篇初稿:\n\n{draft}"}
    ]
    
    while True:
        response = client.messages.create(
            model=MODEL,
            max_tokens=8000,
            system=V3_RESEARCH_PROMPT,
            tools=[...],  # 你自定义的工具
            messages=messages
        )
        
        # 检查 Claude 是否在调用工具
        tool_uses = [b for b in response.content if b.type == "tool_use"]
        
        if not tool_uses:
            # Claude 完成了,返回最终文本
            return "".join(b.text for b in response.content if b.type == "text")
        
        # Claude 在调用工具,执行工具并把结果返回
        messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for tu in tool_uses:
            result = execute_tool(tu.name, tu.input)  # 你的工具执行函数
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tu.id,
                "content": result
            })
        messages.append({"role": "user", "content": tool_results})
        
        # 循环继续,Claude 看到工具结果后决定下一步
```

## 错误处理

- **API 错误**:用 `try/except` 包裹,捕捉 `anthropic.APIError`,失败时保存已有的中间结果。
- **token 超限**:Step 2 的 research 报告可能很长(包含多个 URL 和引文),如果接近 max_tokens 限制,提示用户增加 max_tokens 或切换更大模型。
- **工具调用失败**:如果 web search 返回空或错误,在 research 报告里如实标注"工具不可用,此条无法验证",不要假装查到了。

## 配置和密钥

`.env` 文件:

```
ANTHROPIC_API_KEY=sk-ant-...
```

不要把 API key 写进代码或提交到 git。

## 跑一次的方式

```bash
# 简单跑
python run.py brainrot

# 带出处和原句
python run.py concerning "周会后老板的邮件" "My manager said some of these numbers are concerning."
```

## 后续可以加的功能(不在第一版需求里)

- 批量跑多个词
- 不同模型可配置(快/慢/便宜/贵)
- 把 Step 2 的搜索结果缓存到本地,避免重复搜索
- Web UI(让 Leon 在浏览器里直接跑,不用命令行)
- 集成到他的内容生产工具(比如直接生成 Notion 页面)

第一版只需要"输入一个词,产出三份 md 文件"。其他都是后续迭代。
